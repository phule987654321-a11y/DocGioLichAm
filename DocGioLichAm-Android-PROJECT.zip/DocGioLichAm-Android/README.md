# Đọc Giờ & Lịch Âm — Android wrapper

Dự án này đóng gói nguyên file HTML hiện tại vào Android WebView. File HTML được giữ nguyên trong `app/src/main/assets/index.html`.

## Build APK
Mở thư mục này bằng Android Studio, chọn Gradle JDK tương thích, rồi Build > Build APK(s).

APK debug thường nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

Lưu ý: môi trường tạo file hiện tại không có Android SDK/Gradle build-tools nên không thể biên dịch APK nhị phân ngay trong phiên này. Đây là source project hoàn chỉnh để build APK, không phải PWA.
